package com.cg.dao;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import com.cg.bean.PayBean;

public class PayDao {
	
	PayBean bean = new PayBean();
	EntityManagerFactory emf = Persistence.createEntityManagerFactory("WalletUsingJPA");
	EntityManager em = emf.createEntityManager();
	EntityManager em1 = emf.createEntityManager();
	int row = 0;
	
	public void addUser(PayBean p) {
		em.getTransaction().begin();
		em.persist(p);
		em.getTransaction().commit();
	}
 
	 public double display(long accno) {
		 PayBean bean = em.find(PayBean.class, accno);
			if(bean!=null)
				return bean.getBalance();
			else
				return -1;	
		}
 
 public boolean deposit(long accno,double balance) {
	 PayBean bean = em.find(PayBean.class, accno);
		if(bean!=null) {
			Double bal  = bean.getBalance();
			bal = bal + balance;
			em.getTransaction().begin();
			bean.setBalance(bal);
			em.getTransaction().commit();
			return true;
		}
		else
			return false;
 }
 
 public boolean Withdraw(long accno,double balance) {
	 PayBean bean = em.find(PayBean.class, accno);
		if(bean!=null) {
			Double bal  = bean.getBalance();
			if(bal<=balance)
				return false;
			bal = bal - balance;
			em.getTransaction().begin();
			bean.setBalance(bal);
			em.getTransaction().commit();
			return true;
		}
		else
			return false;
 }
 
 public boolean transferFund(long sourceaccno,long destinationaccno,double transferamount) {
	 PayBean bean = em.find(PayBean.class, sourceaccno);
		if(bean!=null) {
			Double bal  = bean.getBalance();
			if(bal<=transferamount)
				return false;
			bal = bal - transferamount;
			em.getTransaction().begin();
			bean.setBalance(bal);
		}
		else
			return false;
		PayBean bean1 = em1.find(PayBean.class, destinationaccno);
		if(bean1!=null) {
			Double bal1 = bean1.getBalance();
			bal1 = bal1 + transferamount;
			em1.getTransaction().begin();
			bean1.setBalance(bal1);
		}
		else
			return false;
		em.getTransaction().commit();
		em1.getTransaction().commit();
		return true;
 }

}
