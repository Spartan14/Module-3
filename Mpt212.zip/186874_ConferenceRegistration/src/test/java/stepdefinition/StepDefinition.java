package stepdefinition;

import org.openqa.selenium.support.PageFactory;

import Demo.ElementLocators;
import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;

public class StepDefinition {
	
	@Given("^The user is on conference login page$")
	public void the_user_is_on_conference_login_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		 PageFactPack.PageFactory.openbrowser("file:///C:/Users/bhawmish/Desktop/M4%20set1%20webpages/ConferenceRegistartion.html");
	}

	@When("^Enter the invalid First Name$")
	public void enter_the_invalid_First_Name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		PageFactPack.PageFactory.SendValue(ElementLocators.FirstName, "");
		PageFactPack.PageFactory.clickmethod(ElementLocators.Next);
	}

	@Then("^Accept the Alert for First Name$")
	public void accept_the_Alert_for_First_Name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		PageFactPack.PageFactory.Alert("Please fill the First Name");  
	}

	@Then("^Enter the valid First Name$")
	public void enter_the_valid_First_Name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		PageFactPack.PageFactory.SendValue(ElementLocators.FirstName, "Bhawani");
	}

	@When("^Enter the invalid Last Name$")
	public void enter_the_invalid_Last_Name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		PageFactPack.PageFactory.SendValue(ElementLocators.LastName, "");
		PageFactPack.PageFactory.clickmethod(ElementLocators.Next);
	}

	@Then("^Accept the Alert for Last Name$")
	public void accept_the_Alert_for_Last_Name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		PageFactPack.PageFactory.Alert("Please fill the Last Name"); 
	}

	@Then("^Enter the valid Last Name$")
	public void enter_the_valid_Last_Name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		PageFactPack.PageFactory.SendValue(ElementLocators.LastName, "Mishra");
	}

	@When("^Enter the invalid Email$")
	public void enter_the_invalid_Email() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		PageFactPack.PageFactory.SendValue(ElementLocators.Email, "");
		PageFactPack.PageFactory.clickmethod(ElementLocators.Next);
	}

	@Then("^Accept the Alert for Email$")
	public void accept_the_Alert_for_Email() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		PageFactPack.PageFactory.Alert("Please fill the Email");
	}

	@Then("^Enter the valid Email$")
	public void enter_the_valid_Email() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		PageFactPack.PageFactory.SendValue(ElementLocators.Email, "abcd@gmail.com");
	}

	@When("^Enter the invalid Mobile_no$")
	public void enter_the_invalid_Mobile_no() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		PageFactPack.PageFactory.SendValue(ElementLocators.Phone, "");
		PageFactPack.PageFactory.clickmethod(ElementLocators.Next);
	}

	@Then("^Accept the Alert for Mobile_no$")
	public void accept_the_Alert_for_Mobile_no() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		PageFactPack.PageFactory.Alert("Please enter valid contact number");
	}

	@Then("^Enter the valid Mobile_no$")
	public void enter_the_valid_Mobile_no() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		PageFactPack.PageFactory.SendValue(ElementLocators.Phone, "9876543211");
	}

	@When("^Enter the invalid Room_no$")
	public void enter_the_invalid_Room_no() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		PageFactPack.PageFactory.SendValue(ElementLocators.RoomNo, "");
		PageFactPack.PageFactory.clickmethod(ElementLocators.Next);
	}

	@Then("^Accept the Alert for Room_no$")
	public void accept_the_Alert_for_Room_no() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		PageFactPack.PageFactory.Alert("Please enter valid Room number");
		}

	@Then("^Enter the valid Room_no$")
	public void enter_the_valid_Room_no() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		PageFactPack.PageFactory.SendValue(ElementLocators.RoomNo, "A508");
	}

	@When("^Enter the invalid City$")
	public void enter_the_invalid_City() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		PageFactPack.PageFactory.SendValue(ElementLocators.City, "");
		PageFactPack.PageFactory.clickmethod(ElementLocators.Next);
	}

	@Then("^Accept the Alert for City$")
	public void accept_the_Alert_for_City() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		PageFactPack.PageFactory.Alert("Please enter valid City");
	}

	@Then("^Enter the valid City$")
	public void enter_the_valid_City() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		PageFactPack.PageFactory.SendValue(ElementLocators.City, "Raipur");
	}

	@When("^Enter the invalid State$")
	public void enter_the_invalid_State() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		PageFactPack.PageFactory.SendValue(ElementLocators.State, "");
		PageFactPack.PageFactory.clickmethod(ElementLocators.Next);
	}

	@Then("^Accept the Alert for State$")
	public void accept_the_Alert_for_State() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		PageFactPack.PageFactory.Alert("Please enter valid State");
	}

	@Then("^Enter the valid State$")
	public void enter_the_valid_State() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		PageFactPack.PageFactory.SendValue(ElementLocators.State, "Chattisgarh");
	}

	@When("^Enter the invalid Number of people attending$")
	public void enter_the_invalid_Number_of_people_attending() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		PageFactPack.PageFactory.SendValue(ElementLocators.Number, "");
		PageFactPack.PageFactory.clickmethod(ElementLocators.Next);
	}

	@Then("^Accept the Alert for Number of people attending$")
	public void accept_the_Alert_for_Number_of_people_attending() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		PageFactPack.PageFactory.Alert("Please enter valid Number of people");

	}

	@Then("^Enter the valid Number of people attending$")
	public void enter_the_valid_Number_of_people_attending() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		PageFactPack.PageFactory.select(ElementLocators.Number, "5");
	}

	@When("^Enter the invalid Member$")
	public void enter_the_invalid_Member() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		PageFactPack.PageFactory.SendValue(ElementLocators.Member, "");
		PageFactPack.PageFactory.clickmethod(ElementLocators.Next);
	}

	@Then("^Accept the Alert for Member$")
	public void accept_the_Alert_for_Member() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		PageFactPack.PageFactory.Alert("Please Select Membership status");
	}

	@Then("^Enter the valid Member$")
	public void enter_the_valid_Member() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		PageFactPack.PageFactory.clickmethod(ElementLocators.Member);
	}

	@When("^Enter the invalid Non Member$")
	public void enter_the_invalid_Non_Member() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		PageFactPack.PageFactory.SendValue(ElementLocators.NonMember, "");
		PageFactPack.PageFactory.clickmethod(ElementLocators.Next);
	}

	@Then("^Accept the Alert for Non Member$")
	public void accept_the_Alert_for_Non_Member() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		PageFactPack.PageFactory.Alert("Please Select Membership status");
	}

	@Then("^Enter the valid Non Member$")
	public void enter_the_valid_Non_Member() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		PageFactPack.PageFactory.clickmethod(ElementLocators.NonMember);
	}

	@Then("^User is scuccessfully logged in$")
	public void user_is_scuccessfully_logged_in() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		PageFactPack.PageFactory.clickmethod(ElementLocators.Next);
	}

	@When("^Enter the invalid Card holder name$")
	public void enter_the_invalid_Card_holder_name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		PageFactPack.PageFactory.SendValue(ElementLocators.HolderName, "");
		PageFactPack.PageFactory.clickmethod(ElementLocators.Next);
	}

	@Then("^Accept the Alert for Card holder name$")
	public void accept_the_Alert_for_Card_holder_name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		PageFactPack.PageFactory.Alert("Please enter valid Card Holder name");
	}

	@Then("^Enter the valid Card holder name$")
	public void enter_the_valid_Card_holder_name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		PageFactPack.PageFactory.select(ElementLocators.HolderName,"Bhawani");
	}

	@When("^Enter the invalid Debit card number$")
	public void enter_the_invalid_Debit_card_number() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		PageFactPack.PageFactory.SendValue(ElementLocators.CardNumber, "");
		PageFactPack.PageFactory.clickmethod(ElementLocators.Next);
	}

	@Then("^Accept the Alert for Debit card number$")
	public void accept_the_Alert_for_Debit_card_number() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		PageFactPack.PageFactory.Alert("Please enter valid Debit card number");
	}

	@Then("^Enter the valid Debit card number$")
	public void enter_the_valid_Debit_card_number() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		PageFactPack.PageFactory.select(ElementLocators.CardNumber,"1234567890");
	}

	@When("^Enter the invalid CVV$")
	public void enter_the_invalid_CVV() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		PageFactPack.PageFactory.SendValue(ElementLocators.Cvv, "");
		PageFactPack.PageFactory.clickmethod(ElementLocators.Next);
	}

	@Then("^Accept the Alert for CVV$")
	public void accept_the_Alert_for_CVV() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		PageFactPack.PageFactory.Alert("Please enter valid CVV");
	}

	@Then("^Enter the valid CVV$")
	public void enter_the_valid_CVV() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		PageFactPack.PageFactory.select(ElementLocators.Cvv,"456");
	}

	@When("^Enter the invalid Expiration Month$")
	public void enter_the_invalid_Expiration_Month() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		PageFactPack.PageFactory.SendValue(ElementLocators.ExpMonth, "");
		PageFactPack.PageFactory.clickmethod(ElementLocators.Next);
	}

	@Then("^Accept the Alert for Expiration Month$")
	public void accept_the_Alert_for_Expiration_Month() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		PageFactPack.PageFactory.Alert("Please enter valid Expiry month");
	}

	@Then("^Enter the valid Expiration Month$")
	public void enter_the_valid_Expiration_Month() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		PageFactPack.PageFactory.select(ElementLocators.ExpMonth,"March");
	}

	@When("^Enter the invalid Expiration Year$")
	public void enter_the_invalid_Expiration_Year() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		PageFactPack.PageFactory.SendValue(ElementLocators.ExpYear, "");
		PageFactPack.PageFactory.clickmethod(ElementLocators.Next);
	}

	@Then("^Accept the Alert for Expiration Year$")
	public void accept_the_Alert_for_Expiration_Year() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		PageFactPack.PageFactory.Alert("Please enter valid Expiry year");
	}

	@Then("^Enter the valid Expiration Year$")
	public void enter_the_valid_Expiration_Year() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		PageFactPack.PageFactory.select(ElementLocators.ExpMonth,"2025");
	}
	
	@When("^clicks on Confirm Payment$")
	public void clicks_on_Confirm_Booking() throws Throwable {
		PageFactPack.PageFactory.clickmethod(ElementLocators.MakePayment);

	    
	}

	@Then("^User is successfully registered$")
	public void user_is_successfully_registered() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		PageFactPack.PageFactory.close();
	}


}