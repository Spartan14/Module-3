package com.capgemini.project.service;

import java.sql.SQLException;
import java.util.ArrayList;

import com.capgemini.exception.AccountExistException;
import com.capgemini.exception.InvalidInputDetailException;
import com.capgemini.exception.InsufficientAmountException;
import com.capgemini.project.bean.PaymentWalletBean;
import com.capgemini.project.dao.PaymentWalletDao;

public class PaymentWalletService implements PaymentWalletServiceInterface{
	
	PaymentWalletDao walletDaobj = new PaymentWalletDao();
	Long accNo=null;
	int row=0;
	Boolean result = false;

	public Long createAccount(PaymentWalletBean walletBeanObj) throws InvalidInputDetailException, SQLException{
		if(emailCheck(walletBeanObj.getEmailId()) && numberCheck(walletBeanObj.getMobileNumber()) && nameCheck(walletBeanObj.getName()) && walletBeanObj.getName().length()>=3) {
			accNo = Math.abs((Long.parseLong(walletBeanObj.getMobileNumber())-12341)*13);
			walletBeanObj.setAccountNumber(accNo);
			row=walletDaobj.accountCreation(walletBeanObj);
		} 
		else {
			throw new InvalidInputDetailException("Error Occured!!! Enter valid input");
		}
		if(row>0)
			return accNo;
		else
			return null;
	}
	
	public Double showBalance(Long accountNumber) throws AccountExistException, SQLException {
		Double balance = walletDaobj.showBalance(accountNumber);;
		return balance;
	}
	
	public Boolean deposit(Double depositAmount, Long accountNumber) throws AccountExistException, SQLException {
		return result= walletDaobj.depositAmt(depositAmount, accountNumber);
	}
	
	public Boolean withdraw(Double withdrawAmount, Long accountNumber) throws AccountExistException, InsufficientAmountException, SQLException {
		return result = walletDaobj.withdrawAmt(withdrawAmount, accountNumber);
	}
	
	public Boolean fundTransfer(Double amount, Long sourceAccNumber, Long receiverAccNumber) throws InsufficientAmountException, AccountExistException, SQLException {
		return result = walletDaobj.transfer(amount, sourceAccNumber, receiverAccNumber);
		
	}
	
	public ArrayList<String> printTransaction(Long accountNumber) throws AccountExistException, SQLException {
		ArrayList<String> alist = walletDaobj.getTransactions(accountNumber);
		try {
			if(alist!=null)
				return alist;
			else 
				throw new AccountExistException("Account Number doesn't exist. Please check the account number");
		}
		catch(AccountExistException e) {}
		return null;
	}		
	
	boolean nameCheck(String name) {
		boolean result = name.matches("^[a-zA-Z\\s]*$");
		return result;	
	}
	
	boolean emailCheck(String emailId) {
		boolean result = emailId.matches("^[\\w-_\\.+]*[\\w-_\\.]\\@([\\w]+\\.)+[\\w]+[\\w]$");
		return result;
	}
	
	boolean numberCheck(String mobile) {
		boolean result = false;
				if(mobile.length()==10 && mobile.charAt(0)!='0')
					result=true;
		return result;
		
	}
	public boolean accNoCheck(String acc) {
		boolean result = false;
		result = acc.matches("[0-9]{9,18}");
		return result;
	}
	
}
